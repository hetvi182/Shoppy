package com.shoppy.customer;

class OrderStatus {
}
