package com.shoppy.customer.Common;

import com.shoppy.customer.Model.User;

public class Common {
    public static User currentUser;
}
